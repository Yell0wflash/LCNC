enum LocaleNamespaces {
	COMMON = "common",
	LOGIN = "login",
}

export default LocaleNamespaces;
