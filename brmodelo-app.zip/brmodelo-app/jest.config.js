module.exports = {
  testEnvironment: 'node',
  roots: ["app", "server_app"]
};