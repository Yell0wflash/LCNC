---
name: Requisitar funcionalidade
about: Ideias e sugestões de como melhorar o BRMW
title: ''
labels: Feature request
assignees: ''

---

### Sua sugestão de melhoria é relacionada a algum problema?

Adicione aqui a descrição do problema
_Ex: É muito complicado fazer..._

---

### Descreva sua ideia de como resolver o problema
Adicione aqui como você acha que deveríamos resolver esse problema.
Fique a vontade para adicionar imagens, videos, desenhos ou qualquer material que te ajude a explicar sua proposta de solução

---

### Informações extras
Aqui você pode adicionar qualquer informação extra que ache relevante pra nos ajudar a entender o problema.
