---
name: Reportar Problema
about: Reportar bugs no BRMW
title: ''
labels: Bug
assignees: ''

---

### Link da modelagem
Adicione aqui o link da modelagem na qual você estava trabalhando quando encontrou o problema.

---

### Descreva o problema
Adicione aqui uma breve descrição do problema.

---

### Passos para reproduzir
1. Na tela de...
1. Selecione a opção...
1. Clique em...

---

### Screenshots e/ou video
Adicione aqui imagens ou videos que possam nos ajudar a entender o problema

---

### Sistema operacional e navegador
 - Adicione aqui seu sistema operacional (Windows, MacOS, Linux distro, etc...)
 - Adicione aqui seu navegador (Firefox, Chrome, Edge, etc) e a versão do mesmo

---

### Informações extras
Aqui você pode adicionar qualquer informação extra que ache relevante pra nos ajudar a entender o problema.
