exports.Crypto = require('./hash.js')
